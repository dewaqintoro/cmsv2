import covids from './covids'
import login from './login'

import { combineReducers } from 'redux'

export default combineReducers({
  covids,login
})