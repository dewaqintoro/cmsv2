import covids from './covids'
import { combineReducers } from 'redux'

export default combineReducers({
  covids
})