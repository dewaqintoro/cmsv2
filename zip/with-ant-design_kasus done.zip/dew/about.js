import React, { Component } from 'react'
import Layout from './Layout'
export default class About extends Component {
  render() {
    return (
      <div>
        <Layout>
          <p>About</p>
        </Layout>
      </div>
    )
  }
}
