import '../styles/globals.css'
import '../styles/card.css'
import '../styles/mapku.css'
import '../styles/table.css'
import '../styles/infoBox.css'
// import '../styles/side.css'
// import '../styles/side2.scss'
// import '../styles/side3.scss'




import '../styles/dashboard.css'
import "leaflet/dist/leaflet.css";
import 'bootstrap/dist/css/bootstrap.min.css';
// import 'react-bootstrap-table-next/dist/react-bootstrap-table2.min.css';


function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}

export default MyApp

// import React, { Component } from 'react'

// export default class _app extends Component {
//   render() {
//     return (
//       <div>
        
//       </div>
//     )
//   }
// }
