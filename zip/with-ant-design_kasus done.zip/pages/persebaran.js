import React, { Component } from 'react'
import { Layout, Menu } from 'antd';
const { Header, Content, Footer, Sider } = Layout;
import SideCompDew from './components/SideCompDew';
class persebaranDew extends Component {
  render() {
    return (
      <div> 
      <Layout>
        <SideCompDew aktif="2"/>
        <Layout>
          <Content style={{ margin: '24px 16px 0' }}>
            <div className="site-layout-background" style={{ padding: 24, minHeight: 360 }}>
              <h1>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque aliquid nobis deleniti, laudantium perferendis vitae nulla inventore odit sunt quis sapiente voluptatum modi nesciunt eaque numquam nisi quam qui doloremque, ipsa maxime. Consequatur beatae non dicta quisquam doloribus. Sapiente ducimus pariatur quis aperiam deleniti quos, corrupti quidem rerum! Tempora ut at vero mollitia nostrum, sit ullam necessitatibus minima odio quos aliquid sint ab est adipisci labore nemo nobis inventore, earum molestias error numquam dolorum reprehenderit! Doloribus, praesentium. Libero aliquid asperiores voluptas! Esse voluptatum doloribus fuga tenetur quasi voluptatem quibusdam nobis nemo, cumque explicabo, iste exercitationem deleniti! Voluptatum consectetur minus officiis saepe repudiandae vitae est magnam sint architecto suscipit, delectus doloribus odio tempore dicta aliquid excepturi reprehenderit nemo alias sunt culpa quam itaque. Reiciendis, autem! Quam sapiente labore eligendi non est illum reprehenderit nihil porro nobis error qui dignissimos recusandae, unde odit. Commodi laudantium amet repellat ea quam consectetur saepe molestias, eveniet at, nihil ipsa reiciendis harum maxime ipsam corrupti modi. Tempora sapiente odio ratione, culpa soluta cumque eum rerum debitis nisi ad accusantium mollitia corrupti delectus voluptatem consectetur dignissimos molestias. Magni reprehenderit ab eius exercitationem error odit culpa modi sint harum molestias voluptas quod similique, eos blanditiis suscipit quam. Officiis?</h1>
            </div>
          </Content>
        </Layout>
      </Layout>
    </div>
    )
  }
}

export default persebaranDew